# prod_distributed
Distributed optimization algorithms for multi-SKU production planning
